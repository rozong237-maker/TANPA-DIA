// CONTOH LOGIKA API (belum terhubung database)
// Gunakan ini sebagai blueprint untuk Cloudflare Worker/Node.js.

export default {
  async fetch(request, env) {
    if (request.method !== "POST")
      return new Response(JSON.stringify({valid:false,message:"POST only"}), {
        headers: {"content-type":"application/json"}
      });

    const body = await request.json();
    const license = String(body.license || "");
    const placeId = String(body.placeId || "");

    // TODO: ambil license dari database:
    // const row = await env.DB.prepare(
    //   "SELECT * FROM licenses WHERE license = ?"
    // ).bind(license).first();

    // TODO: validasi:
    // row ada
    // row.status === "ACTIVE"
    // row.place_id === placeId
    // tanggal expired belum lewat

    return new Response(JSON.stringify({
      valid: false,
      message: "Connect this endpoint to your database before production use."
    }), {headers: {"content-type":"application/json"}});
  }
};
