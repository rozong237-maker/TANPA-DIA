# VELCRION License Panel

Ini adalah DEMO dashboard frontend untuk mengelola lisensi Roblox.

PENTING:
Versi ini menyimpan data di browser (localStorage), jadi BELUM cocok untuk lisensi produksi.
Untuk benar-benar mengunci sistem Roblox agar tidak bisa dipakai orang lain, perlu API server + database.

Langkah berikutnya:
1. Upload index.html ke hosting.
2. Buat API endpoint server.
3. Simpan license key di database server, bukan localStorage.
4. Roblox ServerScript memakai HttpService untuk memanggil API.
5. API mengecek key + PlaceId + status + tanggal expired.
6. Jangan menaruh secret/API key di LocalScript.

Endpoint produksi yang nantinya dipakai Roblox:
POST /api/license/check
Body:
{
  "license": "VELCRION-XXXX-XXXX",
  "placeId": 123456789
}

Response valid:
{
  "valid": true,
  "message": "License valid"
}
